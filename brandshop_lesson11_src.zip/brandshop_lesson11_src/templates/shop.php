<h1>
    Каталог товаров
</h1>

<div class="shopUnit">
    <img src="http://placehold.it/308x231" />

    <div class="shopUnitName">
        Название продукта
    </div>
    <div class="shopUnitShortDesc">
        Здесь будет немного текста описывающего продукт.
        Здесь будет немного текста описывающего продукт.
        Здесь будет немного текста описывающего продукт.
    </div>
    <div class="shopUnitPrice">
        Цена: 0000 $
    </div>
    <a href="#" class="shopUnitMore">
        Подробнее
    </a>
</div>