<div id="openedProduct-img">
    <img src="http://placehold.it/342x260">
</div>
<div id="openedProduct-content">
    <h1 id="openedProduct-name">
        Название продукта
    </h1>
    <div id="openedProduct-desc">
        Здесь будет описание продукта. Здесь будет описание продукта. Здесь будет описание продукта.
        Здесь будет описание продукта. Здесь будет описание продукта. Здесь будет описание продукта.
        Здесь будет описание продукта. Здесь будет описание продукта. Здесь будет описание продукта.
    </div>
    <div id="openedProduct-price">
        Цена: 0000 $
    </div>
</div>